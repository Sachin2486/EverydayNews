#Installation steps:
        
        Step 1: Clone/Download zip from git.

        Step 2: Extract this folder in xampp htdocs folder as everydayNews folder.

        Step 3: Import database to phpMyAdmin (SQL file located in the root/database/news-cms.sql)
               - Go to localhost/phpmyadmin
               - select "Import" menu option from the top.
               - Click "Choose File" button and select your database.sql file.
               - press "go" button from bottom of the screen

        Step 4: Access your project with localhost/everydayNews

#Login Details:

        -To login as an ADMIN (localhost/everydayNews/admin):

                Username: mushfiq123
                Password: admin

        -To login as a NORMAL USER (localhost/everydayNews/admin):

                Username: rahman123
                Password: 123456
