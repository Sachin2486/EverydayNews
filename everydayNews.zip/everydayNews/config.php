<?php 
$hostname = "http://localhost/everydayNews";

$conn = mysqli_connect("localhost","root","","everyday-news") or die("connetion failed: " . mysqli_connect_error());
?>